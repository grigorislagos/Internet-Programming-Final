document.addEventListener('DOMContentLoaded', function() {
    const inputs = document.querySelectorAll('input[type="text"], input[type="password"], input[type="email"]');
    inputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.setAttribute('data-placeholder', this.getAttribute('placeholder'));
            this.removeAttribute('placeholder');
        });
        input.addEventListener('blur', function() {
            if (!this.value) {
                this.setAttribute('placeholder', this.getAttribute('data-placeholder'));
            }
        });
    });
});
