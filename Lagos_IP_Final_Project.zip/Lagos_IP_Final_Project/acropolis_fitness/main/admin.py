from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import Group
from .models import User, WorkoutPlan, ShoppingCart, CartItem

class UserAdmin(BaseUserAdmin):
    list_display = ('email', 'username', 'user_type', 'is_staff', 'is_superuser')
    search_fields = ('email', 'username')
    ordering = ('email',)

    fieldsets = (
        (None, {'fields': ('email', 'username', 'password')}),
        ('Permissions', {'fields': ('is_staff', 'is_superuser')}),
        ('Personal info', {'fields': ('user_type',)}),
    )

    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'username', 'user_type', 'password1', 'password2'),
        }),
    )

admin.site.register(User, UserAdmin)
admin.site.unregister(Group)
admin.site.register(WorkoutPlan)
admin.site.register(ShoppingCart)
admin.site.register(CartItem)