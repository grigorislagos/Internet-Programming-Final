from django.db import migrations
from django.contrib.auth.hashers import make_password

def create_initial_users(apps, schema_editor):
    User = apps.get_model('main', 'User')
    User.objects.create(
        username='adminlagos',
        email='lagos@gmail.com',
        password=make_password('Lamela@21'),
        user_type=2,  # User.ADMIN
        is_superuser=True,
        is_staff=True
    )
    User.objects.create(
        username='user',
        email='user@gmail.com',
        password=make_password('TucuCorrea@21'),
        user_type=1  # User.REGISTERED
    )

class Migration(migrations.Migration):

    dependencies = [
        ('main', '0001_initial'),
    ]

    operations = [
        migrations.RunPython(create_initial_users),
    ]
