from django.urls import path
from django.contrib.auth.views import LogoutView
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.register, name='register'),
    path('login/', views.user_login, name='login'),
    path('profile/', views.profile, name='profile'),
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('admin-dashboard/add-workout-plan/', views.add_workout_plan, name='add_workout_plan'),
    path('admin-dashboard/edit-workout-plan/<int:pk>/', views.edit_workout_plan, name='edit_workout_plan'),
    path('admin-dashboard/delete-workout-plan/<int:pk>/', views.delete_workout_plan, name='delete_workout_plan'),
    path('admin-dashboard/add-user/', views.add_user, name='add_user'),
    path('admin-dashboard/delete-user/<int:pk>/', views.delete_user, name='delete_user'),
    path('change-password/', views.change_password, name='change_password'),
    path('contact/', views.contact, name='contact'),
    path('about/', views.about, name='about'),
    path('logout/', views.logout_view, name='logout'),
    path('registered_home/', views.home, name='registered_home'),
    path('cart/', views.shopping_cart, name='shopping_cart'),
    path('add-to-cart/<str:plan_name>/', views.add_to_cart, name='add_to_cart'),
    path('remove-from-cart/<str:plan_name>/', views.remove_from_cart, name='remove_from_cart'),
    path('checkout/', views.checkout, name='checkout'),
    path('thank_you/', views.thank_you, name='thank_you'),
    path('workout/<str:plan_name>/', views.workout_plan_details, name='workout_plan_details'),
]
