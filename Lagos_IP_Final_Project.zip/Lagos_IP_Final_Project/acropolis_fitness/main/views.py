from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate, update_session_auth_hash, get_user_model
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth.forms import PasswordChangeForm, UserCreationForm, AuthenticationForm
from django.contrib import messages
from django.core.exceptions import ObjectDoesNotExist
from django.template.loader import get_template
from django.template import TemplateDoesNotExist
from django.db.models import Q 
from .forms import UserRegistrationForm, UserLoginForm, WorkoutPlanForm, AdminUserCreationForm, ProfileForm, ContactForm
from .models import WorkoutPlan, User, ShoppingCart
import logging

#homepage
def home(request):
    query = request.GET.get('q')
    category = request.GET.get('category')
    workout_plans = WorkoutPlan.objects.all()
    
    if query:
        workout_plans = workout_plans.filter(name__icontains=query)
    if category:
        workout_plans = workout_plans.filter(category__iexact=category)
    
    return render(request, 'main/home.html', {'workout_plans': workout_plans})

#register page
def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.user_type = User.REGISTERED
            user.save()
            login(request, user)
            return redirect('home')
    else:
        form = UserRegistrationForm()
    return render(request, 'main/register.html', {'form': form})

User = get_user_model()

#function for logiin
def user_login(request):
    if request.method == 'POST':
        form = UserLoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                if user.user_type == User.ADMIN:
                    messages.success(request, 'Welcome, Admin!')
                    return redirect('admin_dashboard')
                else:
                    messages.success(request, 'Welcome!')
                    return redirect('home')
            else:
                messages.error(request, 'Invalid username or password.')
    else:
        form = UserLoginForm()
    return render(request, 'main/login.html', {'form': form})

#check you rprofile - need to be logged on
@login_required
def profile(request):
    if request.method == 'POST':
        form = ProfileForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Your profile has been updated!')
            return redirect('profile')
    else:
        form = ProfileForm(instance=request.user)
    return render(request, 'main/profile.html', {'form': form})

@staff_member_required
def admin_dashboard(request):
    workout_plans = WorkoutPlan.objects.all()
    users = User.objects.filter(user_type=User.REGISTERED)
    context = {
        'workout_plans': workout_plans,
        'users': users,
        'total_users': User.objects.count(),
        'total_workout_plans': workout_plans.count()
    }
    return render(request, 'main/admin_dashboard.html', context)

#has to be admin
@staff_member_required
def add_workout_plan(request):
    if request.method == 'POST':
        form = WorkoutPlanForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('admin_dashboard')
    else:
        form = WorkoutPlanForm()
    return render(request, 'main/add_workout_plan.html', {'form': form})

@staff_member_required
def edit_workout_plan(request, pk):
    workout_plan = get_object_or_404(WorkoutPlan, pk=pk)
    if request.method == 'POST':
        form = WorkoutPlanForm(request.POST, request.FILES, instance=workout_plan)
        if form.is_valid():
            form.save()
            return redirect('admin_dashboard')
    else:
        form = WorkoutPlanForm(instance=workout_plan)
    return render(request, 'main/edit_workout_plan.html', {'form': form})

@staff_member_required
def delete_workout_plan(request, pk):
    workout_plan = get_object_or_404(WorkoutPlan, pk=pk)
    workout_plan.delete()
    return redirect('admin_dashboard')

@staff_member_required
def add_user(request):
    if request.method == 'POST':
        form = AdminUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('admin_dashboard')
    else:
        form = AdminUserCreationForm()
    return render(request, 'main/add_user.html', {'form': form})

@user_passes_test(lambda u: u.is_superuser)
def delete_user(request, pk):
    user = get_object_or_404(User, pk=pk)
    user.delete()
    return redirect('admin_dashboard')

def contact(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            # Process the form data (e.g., send email)
            messages.success(request, "Your message has been sent. We'll get back to you soon!")
            return redirect('contact')
    else:
        form = ContactForm()
    return render(request, 'main/contact.html', {'form': form})

def about(request):
    return render(request, 'main/about.html')

from django.shortcuts import render, get_object_or_404
from django.core.exceptions import ObjectDoesNotExist
from .models import WorkoutPlan

def workout_plan_details(request, plan_name):
    try:
        plan = WorkoutPlan.objects.get(id=plan_name)
    except (ValueError, ObjectDoesNotExist):
        plan = get_object_or_404(WorkoutPlan, name=plan_name)
    return render(request, 'main/workout_plan_details.html', {'plan': plan})

@login_required
def shopping_cart(request):
    cart, created = ShoppingCart.objects.get_or_create(user=request.user)
    # Recommend a workout plan based on the highest price in the cart
    categories_in_cart = cart.items.values_list('category', flat=True)
    recommended_plan = None
    
    if categories_in_cart:
        # Check the category with the highest price item
        highest_price_item = cart.items.order_by('-price').first()
        if highest_price_item:
            recommended_plan = WorkoutPlan.objects.filter(
                category=highest_price_item.category
            ).exclude(id__in=cart.items.all()).order_by('-price').first()

        # If no plan in the same category is available, recommend the closest category
        if not recommended_plan:
            recommended_plan = WorkoutPlan.objects.exclude(id__in=cart.items.all()).order_by('-price').first()

    return render(request, 'main/shopping_cart.html', {'cart': cart, 'recommended_plan': recommended_plan})

logger = logging.getLogger(__name__)

@login_required
def add_to_cart(request, plan_name):
    workout_plan = get_object_or_404(WorkoutPlan, name=plan_name)
    cart, created = ShoppingCart.objects.get_or_create(user=request.user)
    cart.items.add(workout_plan)
    if request.POST.get('redirect') == 'yes':
        return redirect('shopping_cart')
    messages.success(request, f'{workout_plan.name} has been added to your cart.')
    return redirect('workout_plan_details', plan_name=plan_name)  # Change 'name' to 'plan_name'

@login_required
def remove_from_cart(request, plan_name):
    cart = ShoppingCart.objects.get(user=request.user)
    workout_plan = get_object_or_404(WorkoutPlan, name=plan_name)
    cart.items.remove(workout_plan)
    messages.success(request, 'Item removed from cart.')
    return redirect('shopping_cart')
    
@login_required
def checkout(request):
    if request.method == 'POST':
        address = request.POST.get('address')
        city = request.POST.get('city')
        postal_code = request.POST.get('postal_code')
        cart_items = ShoppingCart.objects.filter(user=request.user)
        
        # Clear the cart
        cart_items.delete()

        messages.success(request, 'Thank you for your purchase. Check your email for the order details.')
        return redirect('thank_you')
    return redirect('shopping_cart')

def logout_view(request):
    logout(request)
    messages.success(request, "You have been successfully logged out.")
    return redirect('home')

@login_required
def change_password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  
            messages.success(request, 'Your password was successfully updated!')
            return redirect('profile')
        else:
            messages.error(request, 'Please correct the error below.')
    else:
        form = PasswordChangeForm(request.user)
    return render(request, 'main/change_password.html', {
        'form': form
    })

def get_recommended_plan(cart):
    categories = [item.category for item in cart.items.all()]
    if not categories:
        return None

    most_common_category = max(set(categories), key=categories.count)
    recommended_plan = WorkoutPlan.objects.filter(category=most_common_category).exclude(id__in=[item.id for item in cart.items.all()]).order_by('-price').first()
    if not recommended_plan:
        next_category = 'Intermediate' if most_common_category == 'Advanced' else 'Novice'
        recommended_plan = WorkoutPlan.objects.filter(category=next_category).exclude(id__in=[item.id for item in cart.items.all()]).order_by('-price').first()
    return recommended_plan

def thank_you(request):
    return render(request, 'main/thank_you.html')